CREATE TABLE match_results (
    match_id INTEGER PRIMARY KEY,
    date DATE,
    team_1 TEXT,
    team_2 TEXT,
    map TEXT,
    result_1 INTEGER,
    result_2 INTEGER,
    map_winner TEXT,
    starting_CT TEXT,
    ct_1 INTEGER,
    t_1 INTEGER,
    ct_2 INTEGER,
    t_2 INTEGER,
    rank_1 INTEGER,
    rank_2 INTEGER,
    map_wins_1 INTEGER,
    map_wins_2 INTEGER,
    match_winner TEXT
);

CREATE TABLE picks_bans (
    match_id INTEGER PRIMARY KEY,
    date DATE,
    team_1 TEXT,
    team_2 TEXT,
    best_of TEXT,
    t1_removed_1 TEXT,
    t1_removed_2 TEXT,
    t2_removed_1 TEXT,
    t2_removed_2 TEXT,
    t1_picked_1 TEXT,
    t2_picked_1 TEXT,
    left_over TEXT,
    FOREIGN KEY (match_id) REFERENCES match_results(match_id)
);