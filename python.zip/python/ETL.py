import pandas as pd
import sqlite3
import os

def run_etl():
    # 1. Definir os caminhos CORRETOS (certifique-se que esses arquivos estão nessas pastas)
    # Usei o caminho completo para garantir que o Python encontre
    path_resultados = r"C:\databases\csgo_proMatches\datasets\resultados.csv"
    path_picks = r"C:\databases\csgo_proMatches\datasets\picks_bans.csv"

    print("Carregando Arquivos...")
    
    # 2. USAR as variáveis aqui dentro do read_csv
    try:
        df_results = pd.read_csv(path_resultados)
        df_picks = pd.read_csv(path_picks)
    except FileNotFoundError as e:
        print(f"Erro: O arquivo não foi encontrado no caminho especificado.\n{e}")
        return

    # 3. Limpeza de dados
    #df_results.drop_duplicates(subset=['match_id'], inplace=True)
    #df_picks.drop_duplicates(subset=['match_id'], inplace=True)

    #Conectar com o banco de dados
    print("Conectando ao banco SQL...")
    connect = sqlite3.connect('cs2_data.db')

    df_results.to_sql('match_results', connect, if_exists='replace', index=False)
    df_picks.to_sql('picks_bans', connect, if_exists='replace', index=False)

    connect.close()
    print("Banco de Dados atualizado com Sucesso!")

if __name__ == "__main__":
    run_etl()
    
     

